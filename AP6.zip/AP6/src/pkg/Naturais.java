package pkg;

public class Naturais extends Gerador{

	void gerar(int n) {
		for(int i=0;i<n;i++) {
			System.out.println(i);
		}
		return;
	}

}
