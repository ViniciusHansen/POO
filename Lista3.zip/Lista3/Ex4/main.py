from classses import *


prof1 = Professor()
prof1.nome = "Fabio"
prof2 = Professor()
prof2.nome = "Alberto"

a1 = Aluno()
a1.nome = "Robertinho"
a1.notas = [7,3,9,4,6]
a2 = Aluno()
a2.nome = "João"
a2.notas = [2,7,9,4,1]
a3 = Aluno()
a3.nome = "Jonas"
a3.notas = [7,8,9,8,9]
a4 = Aluno()
a4.nome = "Nicolas"
a4.notas = [2,3,4,5,1]
a5 = Aluno()
a5.nome = "Laura"
a5.notas = [9,9,9,9,9]

print(a1)
print(a2)
print(a3)
print(a4)
print(a5)



