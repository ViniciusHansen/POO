package pkg;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Digrafo dg = new Digrafo();
        Grafo g = new Grafo();

        dg.adicionarVertice();
        dg.adicionarVertice();
        dg.adicionarVertice();
        dg.adicionarVertice();
        dg.adicionarVertice();
        dg.adicionarVertice();
        dg.adicionarAresta(0,1);
        dg.adicionarAresta(1,3);
        dg.adicionarAresta(2,0);

        for(List<Integer> lista : dg.getMa2().values())
            System.out.println(lista);

    }
}
