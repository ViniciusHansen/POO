package pkg;

public abstract class FormaGeometrica {
    protected int medida1, medida2;

    public abstract int calculaArea();
    public abstract int calculaPerimetro();
}
