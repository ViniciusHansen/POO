package exceptions;

public class SemEspaco extends Exception{
    public SemEspaco(String msg){
        super(msg);
    }
}
