package pkg;

public class Equipe<T> {
    private String nome;

    @Override
    public String toString() {
        return "Equipe{" +
                "nome='" + nome + '\'' +
                '}';
    }
}
