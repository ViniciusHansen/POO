package dados;

public enum Quadrante {
    PRIMEIRO,
    SEGUNDO,
    TERCEIRO,
    QUARTO;
}
