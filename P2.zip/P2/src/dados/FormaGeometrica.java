package dados;

public abstract class FormaGeometrica {
    protected int x,y;
    public abstract double calculaPerimetro();
    public abstract double calculaArea();
}
